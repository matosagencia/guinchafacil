/**
 * Fluxo 1a completo ate o pagamento.
 *
 *   /pre-cotacao -> aceitar -> /checkout/cliente -> /checkout/veiculo
 *   -> /pagamento/checkout/{id} -> Brick MP -> cartao de teste
 *
 * Dois cenarios:
 *   - mastercard aprova
 *   - visa aprova
 *
 * Pre-requisitos:
 *   - XAMPP com guinchafacil_dev rodando em http://localhost:8080
 *   - .env com MP sandbox OK
 *   - Reset de sessao a cada teste (contexto novo do Playwright ja cobre)
 */
const { test, expect } = require('@playwright/test');

const BASE = process.env.BASE_URL || 'http://localhost:8080';
const DEBUG = process.env.DEBUG_CHECKOUT === '1';
const T = 20_000;

// Cartoes de teste oficiais MP (sandbox)
const CARDS = {
    master_apro: {
        numero: '5031433215406351',
        cvv: '123',
        mes: '11',
        ano: '2030',
        titular: 'APRO',
        cpf: '12345678909',
    },
    visa_apro: {
        numero: '4235647728025682',
        cvv: '123',
        mes: '11',
        ano: '2030',
        titular: 'APRO',
        cpf: '12345678909',
    },
};

function log(...args) { if (DEBUG) console.log('[1a]', ...args); }

function dados() {
    const ts = Date.now().toString().slice(-8);
    return {
        cliente: {
            nome: `Teste ${ts}`,
            telefone: `2198${ts.slice(-7)}`,
            email: `teste.${ts}@teste.local`,
        },
        veiculo: {
            marca: 'Volkswagen',
            modelo: 'Gol',
            ano: '2020',
            cor: 'Branco',
            placa: `TST${ts.slice(-4)}`,
            uf: 'RJ',
            cidade: 'Rio de Janeiro',
        },
    };
}

async function setupPage(page) {
    page.setDefaultTimeout(T);
    page.on('console', (msg) => {
        const txt = msg.text();
        if (DEBUG && /\[checkout|\[flow|\[cascata|\[Brick|\[GF-DEBUG/.test(txt)) {
            log('console:', txt);
        }
    });
    page.on('pageerror', (err) => log('pageerror:', err.message));
}

async function avancaPreCotacao(page) {
    await page.goto(`${BASE}/pre-cotacao`, { waitUntil: 'networkidle' });

    // 1) Endereco de origem
    const campo = page.locator('input[name="localizacao"], input[placeholder*="ndere" i], input[placeholder*="origem" i]').first();
    if (await campo.count()) {
        await campo.click();
        await campo.fill('Avenida Presidente Antônio Carlos, 280');
        await page.waitForTimeout(1500);
        const sug = page.locator('[role="option"], .suggestion, .address-item').first();
        if (await sug.count()) await sug.click().catch(() => {});
        await page.waitForTimeout(800);
    }

    // 2) Pula pelos estagios do funil ate aparecer "Aceitar"
    for (let i = 0; i < 12; i++) {
        const urlAntes = page.url();
        for (const sel of [
            'button:has-text("Confirmar")',
            'button:has-text("Continuar")',
            'button:has-text("Avançar")',
            'button:has-text("Próximo")',
            'button:has-text("Me orientem")',
            'button:has-text("Reboque")',
            'button:has-text("Resgatar")',
            '[data-action="next"]',
            '[data-mode="me_orientem"]',
        ]) {
            const b = page.locator(sel).first();
            if (await b.count() && await b.isVisible().catch(() => false)) {
                await b.click({ trial: false }).catch(() => {});
                await page.waitForTimeout(900);
                break;
            }
        }
        const aceitar = page.getByRole('button', { name: /aceitar.*pagar|aceitar.*cota/i }).first();
        if (await aceitar.count() && await aceitar.isVisible().catch(() => false)) {
            return aceitar;
        }
        if (page.url() === urlAntes && !page.url().includes('pre-cotacao')) break;
    }

    return page.getByRole('button', { name: /aceitar.*pagar|aceitar.*cota/i }).first();
}

async function aceitaCotacao(page) {
    const botao = await avancaPreCotacao(page);
    if (!(await botao.count())) {
        // Tenta via texto generico
        const b2 = page.getByText(/aceitar.*pagar/i).first();
        if (await b2.count()) await b2.click();
    } else {
        await botao.click();
    }
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(1000);
}

async function criaContaSePreciso(page, cliente) {
    if (page.url().includes('/login')) {
        const btn = page.getByRole('link', { name: /criar conta/i }).first();
        if (await btn.count()) {
            await btn.click();
            await page.waitForLoadState('networkidle');
        }
    }
    await page.waitForURL(/\/checkout\/cliente/, { timeout: T });

    await page.locator('#nome').fill(cliente.nome);
    await page.locator('#telefone').fill(cliente.telefone);
    await page.locator('#email').fill(cliente.email);
    await page.getByRole('button', { name: /continuar/i }).first().click();
    await page.waitForLoadState('networkidle');
}

async function preencheVeiculo(page, veiculo) {
    await page.waitForURL(/\/checkout\/veiculo/, { timeout: T });

    // Espera JS pronto
    await page.waitForFunction(() => {
        const f = document.getElementById('form-novo-veiculo');
        return f && f.style.display !== 'none';
    }, { timeout: 8_000 });

    const marca = page.locator('#marca');
    await marca.click();
    await marca.fill(veiculo.marca);
    await page.waitForTimeout(1200); // carrega modelos
    const mod = page.locator('#modelo');
    await expect(mod).toBeEnabled({ timeout: 5_000 });
    await mod.click();
    await mod.fill(veiculo.modelo);

    await page.locator('#ano').selectOption(veiculo.ano);
    await page.locator('#cor').selectOption({ label: veiculo.cor });
    await page.locator('#placa').fill(veiculo.placa);
    await page.locator('#uf_placa').selectOption(veiculo.uf);
    await page.locator('#cidade_placa').fill(veiculo.cidade);

    await page.locator('#btn-continuar').click();
    await page.waitForURL(/\/pagamento\/checkout\/\d+/, { timeout: T });
    await page.waitForLoadState('networkidle');
}

async function preencheBrick(page, cartao, cliente) {
    // Espera o Brick carregar (iframe de secure-fields)
    log('aguardando Brick...');
    const cardNumberIframe = page.frameLocator('iframe[name*="cardNumber" i], iframe[title*="card number" i], iframe[title*="número" i]').first();

    // Tenta varias formas de detectar se o Brick ja montou
    await page.waitForFunction(() => {
        const c = document.querySelector('#mp-payment-brick-container');
        if (!c) return false;
        return c.querySelector('iframe') !== null || c.children.length > 0;
    }, { timeout: 25_000 });

    // Espera o primeiro iframe de input aparecer
    const iframes = page.locator('#mp-payment-brick-container iframe');
    await expect.poll(async () => await iframes.count(), { timeout: 20_000 }).toBeGreaterThan(0);
    await page.waitForTimeout(2500); // Brick interno renderiza em camadas

    // Preenche numero do cartao
    log('digitando numero do cartao');
    await cardNumberIframe.locator('input').fill(cartao.numero);
    await page.waitForTimeout(4000); // parcelas demoram

    // CVV
    const cvvIframe = page.frameLocator('iframe[name*="securityCode" i], iframe[title*="cvv" i], iframe[title*="segurança" i], iframe[title*="security" i]').first();
    await cvvIframe.locator('input').fill(cartao.cvv);

    // Validade (MP as vezes usa 2 inputs separados)
    const expIframe = page.frameLocator('iframe[name*="expiration" i], iframe[title*="validade" i]').first();
    await expIframe.locator('input').first().fill(cartao.mes);
    const expInputs = expIframe.locator('input');
    if (await expInputs.count() > 1) {
        await expInputs.nth(1).fill(cartao.ano);
    } else {
        await expIframe.locator('input').first().fill(`${cartao.mes}/${cartao.ano}`);
    }

    // Nome do titular
    const nameIframe = page.frameLocator('iframe[name*="cardholderName" i], iframe[title*="nome" i], iframe[title*="titular" i]').first();
    if (await nameIframe.locator('input').count()) {
        await nameIframe.locator('input').fill(cartao.titular);
    }

    // CPF (se campo isolado existir)
    const cpfIframe = page.frameLocator('iframe[name*="identification" i], iframe[title*="documento" i], iframe[title*="cpf" i]').first();
    if (await cpfIframe.locator('input').count()) {
        await cpfIframe.locator('input').fill(cartao.cpf);
    }

    // Email (alguns bricks colocam dentro do próprio brick)
    const emailIframe = page.frameLocator('iframe[name*="email" i], iframe[title*="email" i]').first();
    if (await emailIframe.locator('input').count()) {
        await emailIframe.locator('input').fill(cliente.email);
    }

    // Parcelas - espera e escolhe a 1ª (1x)
    await page.waitForTimeout(2500);
    const selectParcelas = page.locator('select[name*="installments" i], select[aria-label*="parcelas" i]').first();
    if (await selectParcelas.count() && await selectParcelas.isVisible().catch(() => false)) {
        const opts = await selectParcelas.locator('option').count();
        if (opts > 0) await selectParcelas.selectOption({ index: 0 });
    }

    // Botao pagar dentro do Brick
    const btnPagar = page.getByRole('button', { name: /pagar|finalizar|confirmar/i }).last();
    if (await btnPagar.count()) {
        await btnPagar.click();
    }

    // Espera redirect ou erro visivel
    await page.waitForTimeout(8000);
}

// ============================================================
// Testes
// ============================================================

test.describe('Cenario 1a — pagamento com cartao de teste', () => {
    test.setTimeout(180_000);

    test('1a.pay.master: Mastercard 5031... aprovacao', async ({ page }) => {
        await setupPage(page);
        const d = dados();

        await aceitaCotacao(page);
        await criaContaSeIfPreciso(page, d.cliente);
        await preencheVeiculo(page, d.veiculo);

        log('URL pagamento:', page.url());
        await preencheBrick(page, CARDS.master_apro, d.cliente);

        // Se for sucesso, URL muda ou texto aparece
        const sucesso = page.url().match(/\/pagamento\/sucesso\/\d+/);
        const textoAprovado = await page.getByText(/aprovad|sucesso/i).first().count();
        expect(sucesso || textoAprovado, 'pagamento deveria ter sido aprovado').toBeTruthy();
    });

    test('1a.pay.visa: Visa 4235... aprovacao', async ({ page }) => {
        await setupPage(page);
        const d = dados();

        await aceitaCotacao(page);
        await criaContaSeIfPreciso(page, d.cliente);
        await preencheVeiculo(page, d.veiculo);

        log('URL pagamento:', page.url());
        await preencheBrick(page, CARDS.visa_apro, d.cliente);

        const sucesso = page.url().match(/\/pagamento\/sucesso\/\d+/);
        const textoAprovado = await page.getByText(/aprovad|sucesso/i).first().count();
        expect(sucesso || textoAprovado, 'pagamento deveria ter sido aprovado').toBeTruthy();
    });
});

// Helper com o nome consistente com a chamada acima
async function criaContaSeIfPreciso(page, cliente) {
    return criaContaSePreciso(page, cliente);
}